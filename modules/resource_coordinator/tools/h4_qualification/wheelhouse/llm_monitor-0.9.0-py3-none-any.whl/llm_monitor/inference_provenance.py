"""Sanitized outbound inference parameter capture and correlation helpers."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import uuid
from typing import Any

PROVENANCE_SCHEMA = "llm-monitor-effective-inference-v1"
MAX_PROVENANCE_BYTES = 128 * 1024

_CONTENT_KEYS = frozenset({
    "messages",
    "prompt",
    "input",
    "tools",
    "tool_choice",
    "functions",
    "function_call",
    "stream",
    "stream_options",
})

_SENSITIVE_KEY_MARKERS = (
    "api_key",
    "apikey",
    "auth",
    "bearer",
    "cookie",
    "credential",
    "password",
    "passwd",
    "secret",
    "token",
)

_ALLOWED_ROLES = frozenset({"worker", "title", "summary", "compaction"})


_NON_SECRET_KEYS = frozenset({"max_tokens", "max_completion_tokens", "min_tokens"})


def _is_sensitive_key(key: str) -> bool:
    lowered = key.strip().lower()
    if lowered in _NON_SECRET_KEYS:
        return False
    return any(marker in lowered for marker in _SENSITIVE_KEY_MARKERS)


def _sanitize_value(value: Any, redacted_keys: set[str], prefix: str = "") -> Any:
    if isinstance(value, dict):
        cleaned: dict[str, Any] = {}
        for k in sorted(value):
            k_str = str(k)
            full_key = f"{prefix}.{k_str}" if prefix else k_str
            if _is_sensitive_key(k_str):
                redacted_keys.add(full_key)
                continue
            cleaned[k_str] = _sanitize_value(value[k], redacted_keys, full_key)
        return cleaned
    if isinstance(value, list):
        return [_sanitize_value(item, redacted_keys, prefix) for item in value]
    if isinstance(value, (str, bool, int)) or value is None:
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    return str(value)


def sanitize_provider_options(payload: dict[str, Any]) -> tuple[dict[str, Any], str, list[str]]:
    """Extract non-content, non-secret inference options and compute a canonical SHA-256."""
    redacted_keys: set[str] = set()
    options: dict[str, Any] = {}
    for key in sorted(payload):
        key_str = str(key)
        if key_str in _CONTENT_KEYS or key_str == "model":
            continue
        if _is_sensitive_key(key_str):
            redacted_keys.add(key_str)
            continue
        options[key_str] = _sanitize_value(payload[key], redacted_keys, key_str)

    canonical = json.dumps(options, sort_keys=True, separators=(",", ":"), allow_nan=False)
    options_sha256 = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return options, options_sha256, sorted(redacted_keys)


def classify_request_role(payload: dict[str, Any], explicit_role: str | None = None) -> str:
    """Classify whether an outbound request is worker inference or an auxiliary OpenCode task."""
    if explicit_role is not None:
        normalized = explicit_role.strip().lower()
        return normalized if normalized in _ALLOWED_ROLES else "unknown_role"

    messages = payload.get("messages")
    if isinstance(messages, list):
        for msg in messages[:2]:
            if not isinstance(msg, dict) or msg.get("role") != "system":
                continue
            content = msg.get("content")
            if not isinstance(content, str):
                continue
            lowered = content.lower()
            if "generate a title" in lowered or "title generator" in lowered:
                return "title"
            if "summariz" in lowered and "compaction" in lowered:
                return "compaction"
            if "generate a summary" in lowered or "session summary" in lowered:
                return "summary"
    return "worker"


def _positive_int(value: Any) -> int | None:
    if isinstance(value, int) and not isinstance(value, bool) and value > 0:
        return value
    return None


def _finite_number(value: Any) -> int | float | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return value
    return None


def extract_outbound_settings(
    payload: dict[str, Any],
    *,
    request_id: str,
    started_at: str | None,
    correlation: dict[str, Any] | None = None,
    session_id: str | None = None,
    message_id: str | None = None,
    request_role: str | None = None,
) -> dict[str, Any]:
    """Build sanitized, bounded outbound inference parameter evidence from a chat-completions JSON body."""
    model = payload.get("model")
    provider_model_id = model.strip() if isinstance(model, str) and model.strip() else None

    output_limit = _positive_int(payload.get("max_completion_tokens"))
    if output_limit is None:
        output_limit = _positive_int(payload.get("max_tokens"))

    temperature = _finite_number(payload.get("temperature"))
    top_p = _finite_number(payload.get("top_p"))
    top_k = _positive_int(payload.get("top_k"))

    reasoning_effort: str | None = None
    raw_effort = payload.get("reasoning_effort")
    if isinstance(raw_effort, str) and raw_effort.strip():
        reasoning_effort = raw_effort.strip()
    elif isinstance(payload.get("reasoning"), dict):
        nested_effort = payload["reasoning"].get("effort")
        if isinstance(nested_effort, str) and nested_effort.strip():
            reasoning_effort = nested_effort.strip()

    sanitized_options, options_sha256, redacted_keys = sanitize_provider_options(payload)
    resolved_role = classify_request_role(payload, request_role)
    status = "observed" if provider_model_id is not None else "incomplete"

    return {
        "schema": PROVENANCE_SCHEMA,
        "observation_source": "llm_monitor_gateway_outbound",
        "verification_status": status,
        "request_id": request_id,
        "request_timestamp": started_at,
        "provider_model_id": provider_model_id,
        "context_length": None,
        "context_source": "unavailable_in_http_payload",
        "output_limit": output_limit,
        "temperature": temperature,
        "top_p": top_p,
        "top_k": top_k,
        "reasoning_effort": reasoning_effort,
        "options_sha256": options_sha256,
        "sanitized_options": sanitized_options,
        "redacted_keys": redacted_keys,
        "correlation": {
            "benchmark_correlation": correlation,
            "session_id": session_id,
            "message_id": message_id,
            "request_role": resolved_role,
        },
    }


def write_bounded_provenance_file(
    path: Path,
    payload: dict[str, Any],
    *,
    max_bytes: int = MAX_PROVENANCE_BYTES,
) -> None:
    """Atomically persist bounded provenance JSON with restrictive permissions on POSIX."""
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    if len(encoded) > max_bytes:
        raise ValueError(f"Provenance payload exceeds {max_bytes} byte limit")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with tmp_path.open("wb") as handle:
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    if os.name != "nt":
        os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, path)
