import { aggregateSummary, capabilityLabel, durationSeconds, formatDuration, formatTimestamp, safeCount, stateLabel, tokenMetric } from "./formatters.mjs";
import { isActive, requestKey, selectedRequest, visibleRequests } from "./state.mjs";
import { TranscriptView } from "./transcript.mjs";

const CAPABILITY_LABELS = {
  model_inventory: "Model inventory",
  aggregate_metrics: "Aggregate metrics",
  request_lifecycle: "Request lifecycle",
  structured_input: "Structured input",
  reasoning_text: "Reasoning stream",
  output_text: "Output stream",
  token_usage: "Token usage",
  request_timing: "Request timing",
  gpu_samples: "GPU samples",
  historical_content: "Historical content",
};

export function createRenderer() {
  const transcript = new TranscriptView(byId("transcript-content"));
  let lastSelectedKey = null;
  return {
    render(state) {
      renderHeader(state);
      renderSidebar(state);
      renderToolbar(state);
      renderKpis(state);
      renderRequestList(state);
      renderInspector(state, transcript, lastSelectedKey);
      lastSelectedKey = state.selectedRequestKey;
      renderGpu(state);
      renderCapabilities(state);
      renderModelCards(state);
      renderHistory(state);
      renderAlerts(state);
      renderPage(state);
    },
    renderRequestEvent(state, event) {
      const key = requestKey(event.request || event);
      const lifecycle = ["request.started", "request.observed", "request.updated", "request.completed", "request.failed", "request.cancelled", "usage.reported", "telemetry.gap", "stream.interrupted"].includes(event.type);
      if (lifecycle) {
        renderHeader(state);
        renderKpis(state);
        renderRequestList(state);
      }
      if (key === state.selectedRequestKey || lastSelectedKey !== state.selectedRequestKey) {
        renderInspector(state, transcript, lastSelectedKey);
        lastSelectedKey = state.selectedRequestKey;
      }
    },
    renderHardware(state) {
      if (state.page === "overview") {
        renderKpis(state);
        renderGpu(state);
      }
    },
  };
}

function renderHeader(state) {
  const connected = state.servers.filter((server) => server.connection_state === "connected").length;
  const total = state.servers.length;
  const availability = state.transportStatus !== "connected" ? "degraded" : total === 0 ? "unavailable" : connected === total ? "connected" : connected > 0 ? "degraded" : "disconnected";
  const serverStatus = byId("server-status");
  serverStatus.dataset.state = availability;
  const statusText = state.transportStatus !== "connected" ? "Monitor API unavailable" : total === 0 ? "No server found" : connected === total ? "Server connected" : connected > 0 ? "Server degraded" : "Server disconnected";
  replaceText(serverStatus.querySelector("span:last-child"), statusText);
  text("server-count", state.transportStatus === "connected" ? `${connected}/${total} servers` : `${total} servers · stale`);
  text("sidebar-server-count", total ? String(total) : "0");
  text("refresh-time", state.status?.refreshed_at ? `Updated ${new Date(state.status.refreshed_at).toLocaleTimeString()}` : "Waiting for inventory");
  const recording = state.status?.recording || {};
  const metadata = recording.metadata === true;
  const content = recording.content === true;
  const recordStatus = metadata ? content ? "Recording content" : "Recording metadata" : "Recording off";
  text("header-recording", recordStatus);
  text("recording-status", `Metadata recording: ${metadata ? "enabled" : "disabled"} · Content recording: ${content ? "enabled" : "disabled"}`);
  text("sidebar-metadata-recording", `Metadata recording ${metadata ? "on" : "off"}`);
  text("sidebar-content-recording", `Content recording ${content ? "on" : "off"}`);
  const activeCount = state.requests.filter((request) => isActive(request.state)).length;
  const requestCount = byId("active-request-count");
  requestCount.hidden = activeCount === 0;
  requestCount.textContent = String(activeCount);
  const synthetic = state.requests.some((request) => request.source === "synthetic_fixture");
  byId("synthetic-badge").hidden = !synthetic;
}

function renderSidebar(state) {
  const list = byId("server-list");
  const focusedServer = document.activeElement?.dataset?.serverId;
  const oldButtons = new Map(Array.from(list.querySelectorAll("button[data-server-id]"), (button) => [button.dataset.serverId, button]));
  if (!state.servers.length) {
    list.replaceChildren(make("li", "sidebar-empty", "No local servers discovered"));
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const server of state.servers) {
    const id = server.server_instance_id || server.endpoint_id || "unknown-server";
    const button = oldButtons.get(id) || make("button", "server-item");
    button.type = "button";
    button.dataset.serverId = id;
    button.setAttribute("aria-pressed", String(state.selectedServerId === id));
    button.replaceChildren();
    const nameLine = make("span", "server-name-line");
    const indicator = make("span", "server-indicator");
    indicator.dataset.state = server.stale ? "stale" : server.connection_state || "unavailable";
    const provider = make("span", "", providerLabel(server.provider_type));
    nameLine.append(indicator, provider);
    button.append(nameLine, make("span", "server-endpoint", server.endpoint || "Endpoint unavailable"));
    const loaded = state.models.filter((model) => model.server_instance_id === id && model.state === "loaded").length;
    button.append(make("span", "server-meta", `${loaded} loaded model entries · ${server.stale ? "stale observation" : connectionLabel(server.connection_state)}`));
    fragment.append(button);
  }
  list.replaceChildren(fragment);
  if (focusedServer) list.querySelector(`[data-server-id="${CSS.escape(focusedServer)}"]`)?.focus({ preventScroll: true });
}

function renderToolbar(state) {
  const current = state.selectedModelId;

  // Categorize models: loaded, not loaded, unknown
  const loadedModels = [];
  const notLoadedModels = [];
  const unknownModels = [];

  for (const model of state.models) {
    const id = model.model_id || model.id || model.model_instance_id || model.provider_model_id;
    if (!id) continue;
    const name = model.name || model.provider_model_id || "Unknown model";
    const item = { id, name, model, state: model.state };
    if (model.state === "loaded") loadedModels.push(item);
    else if (model.state === "not_loaded") notLoadedModels.push(item);
    else unknownModels.push(item);
  }

  const byName = (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
  loadedModels.sort(byName);
  notLoadedModels.sort(byName);
  unknownModels.sort(byName);

  // Hidden native select (for form/test backwards compatibility)
  const select = byId("model-filter");
  if (select) {
    const options = [makeOption("all", "All monitored models")];
    for (const m of loadedModels) options.push(makeOption(m.id, `${m.name} · loaded`));
    for (const m of notLoadedModels) options.push(makeOption(m.id, `${m.name} · not loaded`));
    for (const m of unknownModels) options.push(makeOption(m.id, `${m.name} · unknown`));
    select.replaceChildren(...options);
    select.value = options.some((option) => option.value === current) ? current : "all";
  }

  // Accessible custom combobox popup listbox
  const popup = byId("model-select-popup");
  if (popup) {
    const fragment = document.createDocumentFragment();

    const allOpt = make("li", "combobox-option");
    allOpt.setAttribute("role", "option");
    allOpt.id = "model-opt-all";
    allOpt.dataset.value = "all";
    allOpt.setAttribute("aria-selected", current === "all" ? "true" : "false");
    allOpt.tabIndex = -1;
    const allPill = make("span", "combobox-status-pill status-pill-all");
    const allText = make("span", "combobox-option-text", "All monitored models");
    allOpt.append(allPill, allText);
    fragment.append(allOpt);

    const addGroup = (groupLabel, items, pillClass, badgeClass, badgeLabel) => {
      if (!items.length) return;
      const labelEl = make("li", "combobox-group-label", groupLabel);
      labelEl.setAttribute("role", "presentation");
      fragment.append(labelEl);
      for (const item of items) {
        const isSelected = item.id === current;
        const opt = make("li", "combobox-option");
        opt.setAttribute("role", "option");
        opt.id = `model-opt-${item.id}`;
        opt.dataset.value = item.id;
        opt.setAttribute("aria-selected", isSelected ? "true" : "false");
        opt.tabIndex = -1;
        const pill = make("span", `combobox-status-pill ${pillClass}`);
        const textSpan = make("span", "combobox-option-text", item.name);
        const badge = make("span", `combobox-option-badge ${badgeClass}`, badgeLabel);
        opt.append(pill, textSpan, badge);
        fragment.append(opt);
      }
    };

    addGroup("Loaded models", loadedModels, "status-pill-loaded", "badge-loaded", "Loaded");
    addGroup("Not loaded", notLoadedModels, "status-pill-not-loaded", "badge-not-loaded", "Not loaded");
    addGroup("Unknown state", unknownModels, "status-pill-unknown", "badge-unknown", "Unknown");

    popup.replaceChildren(fragment);
  }

  // Update custom combobox trigger label and status indicator
  const triggerText = byId("model-select-text");
  const triggerPill = byId("model-trigger-pill");
  if (triggerText && triggerPill) {
    if (current === "all" || !current) {
      triggerText.textContent = "All monitored models";
      triggerPill.className = "combobox-status-pill status-pill-all";
    } else {
      const allItems = [...loadedModels, ...notLoadedModels, ...unknownModels];
      const selectedItem = allItems.find((m) => m.id === current);
      if (selectedItem) {
        triggerText.textContent = selectedItem.name;
        const pClass = selectedItem.state === "loaded" ? "status-pill-loaded" : selectedItem.state === "not_loaded" ? "status-pill-not-loaded" : "status-pill-unknown";
        triggerPill.className = `combobox-status-pill ${pClass}`;
      } else {
        triggerText.textContent = "All monitored models";
        triggerPill.className = "combobox-status-pill status-pill-all";
      }
    }
  }

  // Recording mode control
  const recMode = state.status?.recording?.mode || (state.status?.recording?.enabled ? "metadata" : "off");
  const isRecDisabled = recMode === "off" || recMode === "disabled" || !state.status?.recording?.metadata;
  const recLabel = recMode === "content" ? "Recording: Content" : recMode === "metadata" ? "Recording: Metadata" : "Recording: Disabled";
  const recDot = byId("recording-mode-dot");
  if (recDot) {
    recDot.className = "recording-mode-dot" + (recMode === "content" ? " is-content" : recMode === "metadata" ? " is-metadata" : " is-disabled");
  }
  const recBtnLabel = byId("recording-mode-label");
  if (recBtnLabel) replaceText(recBtnLabel, recLabel);
  const recBtn = byId("recording-mode-btn");
  if (recBtn) {
    if (isRecDisabled) {
      recBtn.title = "Inference recording is disabled on this server. Start LLM Monitor with -R/--record-inferences to enable SQLite persistence.";
      recBtn.setAttribute("aria-disabled", "true");
    } else {
      recBtn.title = `Current recording mode: ${recMode}. Click to switch.`;
      recBtn.removeAttribute("aria-disabled");
    }
  }

  const auto = byId("follow-toggle");
  auto.classList.toggle("is-enabled", state.autoFollow);
  auto.setAttribute("aria-pressed", String(state.autoFollow));
  replaceText(auto.lastChild, state.autoFollow ? "Following live" : "Follow paused");
  const requestsPage = state.page === "requests";
  byId("reasoning-visible").checked = state.reasoningVisible;
  byId("transcript-follow").checked = state.transcriptFollow;
  text("page-title", requestsPage ? "Request stream" : "Local model activity");
  text("page-description", requestsPage ? "Search and inspect observed inference requests." : "Live requests, captured content, and model performance.");
  text("page-breadcrumb", requestsPage ? "REQUESTS" : "OVERVIEW");
  byId("kpi-grid").hidden = requestsPage;
  byId("bottom-grid").hidden = requestsPage;
}

function renderKpis(state) {
  const summary = aggregateSummary(state.requests, state.captureState, state.selectedModelId, state.models);
  text("kpi-requests", summary.requestCount);
  text("kpi-requests-note", summary.requestNote);
  setAverage("input", summary.input, "tokens");
  setAverage("reasoning", summary.reasoning, "reported samples");
  setAverage("output", summary.output, "tokens");
  if (summary.duration) {
    text("kpi-duration", formatDuration(summary.duration.value));
    text("kpi-duration-note", `Observed lifecycle · n=${summary.duration.samples}`);
  } else {
    text("kpi-duration", "—");
    text("kpi-duration-note", "Observed request lifecycle");
  }
  text("kpi-gpu", "—");
  if (summary.gpu) {
    text("kpi-gpu", `${summary.gpu.value.toFixed(1)}%`);
    text("kpi-gpu-note", `Req average · n=${summary.gpu.samples}`);
  } else {
    const gpuSamples = Array.isArray(state.status?.hardware_samples) ? state.status.hardware_samples.map((sample) => sample.gpu_utilization_percent).filter((value) => Number.isFinite(value) && value >= 0 && value <= 100) : [];
    if (gpuSamples.length) {
      text("kpi-gpu", `${(gpuSamples.reduce((sum, value) => sum + value, 0) / gpuSamples.length).toFixed(1)}%`);
      text("kpi-gpu-note", `Device average · not per-request · n=${gpuSamples.length}`);
    } else text("kpi-gpu-note", "Device-level samples unavailable");
  }
}

function setAverage(name, metric, unit) {
  text(`kpi-${name}`, metric ? Math.round(metric.value).toLocaleString() : "—");
  const noteId = `kpi-${name}-note`;
  text(noteId, metric ? `${unit} · n=${metric.samples}` : name === "reasoning" ? "Reported observations only" : "Reported completed requests");
}

function renderRequestList(state) {
  const requests = visibleRequests(state);
  const list = byId("request-list");
  const oldScrollTop = list.scrollTop;
  const focusedRequest = document.activeElement?.dataset?.requestKey;
  const shown = requests.slice(0, state.requestLimit);
  const fragment = document.createDocumentFragment();
  if (!requests.length) {
    const inventoryAvailable = state.status?.capabilities?.model_inventory?.state === "available";
    const captureUnavailable = state.captureState === "unavailable";
    const title = state.search || state.statusFilter !== "all" || state.selectedModelId !== "all" || state.selectedServerId !== "all"
      ? "No requests match these filters" : captureUnavailable && inventoryAvailable ? "No individual requests captured" : captureUnavailable ? "No inference server discovered" : "No requests observed";
    const detail = state.search || state.statusFilter !== "all" ? "Adjust search or filters to see other observed requests." : captureUnavailable && inventoryAvailable ? "Model inventory is available, but no supported request source is connected." : captureUnavailable ? "No model inventory or request source is available yet." : "Requests will appear here when an observation source reports them.";
    const empty = make("div", "request-empty");
    empty.append(make("span", "empty-symbol", "≋"), make("strong", "", title), make("p", "", detail));
    fragment.append(empty);
  } else {
    for (const request of shown) fragment.append(renderRequestRow(request, state));
  }
  list.replaceChildren(fragment);
  list.scrollTop = oldScrollTop;
  if (focusedRequest) list.querySelector(`[data-request-key="${CSS.escape(focusedRequest)}"]`)?.focus({ preventScroll: true });
  text("request-count", state.requestAvailability === "unavailable" || state.captureState === "unavailable" ? "Unavailable" : `${shown.length} of ${requests.length}`);
  text("request-list-status", state.captureState === "unavailable" ? "Request capture unavailable" : `${state.requests.length} in memory`);
  const clear = byId("clear-search");
  clear.hidden = !(state.search || state.statusFilter !== "all" || state.timeRange !== "all" || state.selectedModelId !== "all" || state.selectedServerId !== "all");
  const loadMore = byId("load-more-requests");
  loadMore.hidden = requests.length <= shown.length;
  loadMore.textContent = `Show ${Math.min(100, requests.length - shown.length)} more`;
  const active = state.captureState === "unavailable" ? "Unavailable" : "Observing";
  text("request-source-note", active === "Unavailable" ? "Individual request source unavailable" : `${active} · newest first`);
  document.querySelectorAll("[data-request-count]").forEach((node) => { node.textContent = state.captureState === "unavailable" ? "—" : String(state.requests.length); });
}

function renderRequestRow(request, state) {
  const key = requestKey(request);
  const row = make("button", "request-row");
  row.type = "button";
  row.role = "option";
  row.dataset.requestKey = key;
  row.setAttribute("aria-selected", String(key === state.selectedRequestKey));
  const top = make("span", "request-row-top");
  top.append(make("span", "request-id", shortId(request.request_id)), stateBadge(request.state, "request-state"));
  const preview = make("span", "request-preview", previewText(request));
  const bottom = make("span", "request-row-bottom");
  const metadata = make("span", "request-row-meta");
  metadata.append(make("span", "", formatShortTime(request.started_at)), make("span", "mono", `in ${safeCount(request.input_tokens)}`));
  if (request.coverage?.reasoning_text && request.coverage.reasoning_text !== "unavailable") metadata.append(make("span", "availability-mark", "Reasoning"));
  bottom.append(metadata, make("span", "mono", formatDuration(durationSeconds(request))));
  row.append(top, preview, bottom);
  return row;
}

function renderInspector(state, transcript, previousKey) {
  const request = selectedRequest(state);
  const empty = byId("inspector-content");
  const detail = byId("inspector-detail");
  empty.hidden = Boolean(request);
  detail.hidden = !request;
  byId("return-live").hidden = !request || state.autoFollow;
  if (!request) {
    transcript.clear("Transcript content is unavailable until a request is selected.");
    renderTabs(state.selectedTab, null);
    return;
  }
  const key = requestKey(request);
  text("inspector-heading-detail", shortId(request.request_id, 32));
  renderStateBadge("inspector-state", request.state);
  text("inspector-model", request.model_name || request.provider_model_id || "Model identity unavailable");
  text("inspector-started", formatTimestamp(request.started_at));
  text("inspector-source", sourceLabel(request.source));
  byId("inspector-gap").hidden = request.stream_gap !== true;
  setTokenMetric("detail-input", request, "input_tokens");
  setTokenMetric("detail-reasoning", request, "reasoning_tokens");
  text("detail-input-source", sourceLabel(tokenMetric(request, "input_tokens").source));
  text("detail-reasoning-source", tokenMetric(request, "reasoning_tokens").source.replaceAll("_", " "));
  setTokenMetric("detail-output", request, "output_tokens");
  text("detail-output-source", sourceLabel(tokenMetric(request, "output_tokens").source));
  text("detail-duration", formatDuration(durationSeconds(request)));
  text("detail-gpu", "—");
  const copy = byId("copy-request-id");
  copy.dataset.requestId = request.request_id;
  const transcriptContent = byId("transcript-content");
  if (key !== previousKey) transcriptContent.scrollTop = 0;
  transcript.update(request, { reasoningVisible: state.reasoningVisible, search: state.transcriptSearch, follow: state.transcriptFollow && isActive(request.state) });
  renderTabs(state.selectedTab, request);
}

function renderTabs(selected, request) {
  for (const tab of document.querySelectorAll(".inspector-tab")) {
    const active = tab.dataset.tab === selected;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", String(active));
    tab.tabIndex = active ? 0 : -1;
  }
  for (const panel of document.querySelectorAll("[data-panel]")) panel.hidden = !request || panel.dataset.panel !== selected;
  if (selected === "telemetry" && request) renderTelemetry(request);
  if (selected === "timeline" && request) renderTimeline(request);
}

function renderTelemetry(request) {
  const metrics = [
    ["End-to-end duration", durationSeconds(request), "s", "observed lifecycle"],
    ["Time to first text", request.time_to_first_text_seconds, "s", request.time_to_first_text_source || "unavailable"],
    ["Queue duration", request.queue_seconds, "s", request.queue_source || "unavailable"],
    ["Prefill duration", request.prefill_seconds, "s", request.prefill_source || "unavailable"],
    ["Decode duration", request.decode_seconds, "s", request.decode_source || "unavailable"],
    ["Generation speed", request.generation_tokens_per_second, "tok/s", request.generation_speed_source || "unavailable"],
    ["Input tokens", request.input_tokens, "tokens", tokenMetric(request, "input_tokens").source, "input_tokens"],
    ["Reasoning tokens", request.reasoning_tokens, "tokens", tokenMetric(request, "reasoning_tokens").source, "reasoning_tokens"],
    ["Output tokens", request.output_tokens, "tokens", tokenMetric(request, "output_tokens").source, "output_tokens"],
    ["Cached input", request.cached_input_tokens, "tokens", request.cached_input_source || "unavailable"],
    ["Average GPU", request.gpu_average_percent, "%", request.gpu_scope || "unavailable"],
    ["Peak VRAM", request.gpu_peak_vram_bytes, "bytes", request.gpu_scope || "unavailable"],
  ];
  const grid = byId("telemetry-grid");
  grid.replaceChildren(...metrics.map(([label, value, unit, provenance, field]) => {
    const item = make("div", "telemetry-item");
    const display = field ? tokenMetric(request, field).value : formatMetric(value, unit);
    item.append(make("span", "", label), make("strong", "", unit === "tokens" && display !== "—" ? `${display} tokens` : display), make("small", "", sourceLabel(provenance)));
    return item;
  }));
  const coverage = request.coverage || {};
  const coverText = Object.entries(coverage).map(([key, value]) => `${key.replaceAll("_", " ")}: ${capabilityLabel(value).toLowerCase()}`).join(" · ") || "Coverage metadata unavailable";
  text("telemetry-provenance", `Source: ${sourceLabel(request.source)} · Observed: ${formatTimestamp(request.started_at)} · ${coverText}`);
}

function renderTimeline(request) {
  const list = byId("event-timeline");
  const events = Array.isArray(request.events) ? [...request.events].sort((a, b) => (a.sequence ?? 0) - (b.sequence ?? 0)) : [];
  if (!events.length) {
    list.replaceChildren(make("li", "content-unavailable", "No request event timeline is available from this source."));
    return;
  }
  list.replaceChildren(...events.map((event) => {
    const item = make("li", "timeline-event");
    const time = make("time", "", formatRelative(event.timestamp, request.started_at));
    if (event.timestamp) time.dateTime = event.timestamp;
    const body = make("div", "");
    body.append(make("strong", "", eventLabel(event.type)), make("p", "", event.summary || event.message || "Event details unavailable"));
    item.append(time, body);
    return item;
  }));
}

function renderGpu(state) {
  const samples = Array.isArray(state.status?.hardware_samples) ? state.status.hardware_samples : [];
  const chart = byId("gpu-chart");
  if (!samples.length) {
    chart.setAttribute("aria-label", "GPU activity samples unavailable");
    chart.replaceChildren(make("p", "chart-empty", "GPU samples are unavailable from the current monitor sources."));
    text("gpu-device", "Unavailable");
    text("gpu-average", "—");
    text("gpu-vram", "—");
    return;
  }
  const width = 420;
  const height = 82;
  const points = samples.map((sample, index) => ({ sample, index, value: sample.gpu_utilization_percent, timestamp: Date.parse(sample.timestamp || "") })).filter((point) => Number.isFinite(point.value) && point.value >= 0 && point.value <= 100);
  const values = points.map((point) => point.value);
  if (!values.length) return;
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("class", "gpu-svg");
  svg.setAttribute("role", "presentation");
  for (const y of [25, 50, 75]) {
    const line = document.createElementNS(svg.namespaceURI, "line");
    line.setAttribute("x1", "0"); line.setAttribute("x2", String(width)); line.setAttribute("y1", String(height * (1 - y / 100))); line.setAttribute("y2", String(height * (1 - y / 100))); line.setAttribute("stroke", "#2b3545"); line.setAttribute("stroke-dasharray", "3 5");
    svg.append(line);
  }
  let segment = [];
  let previous = null;
  const drawSegment = () => {
    if (!segment.length) return;
    const coordinates = segment.map((point) => `${samples.length === 1 ? width / 2 : point.index * width / (samples.length - 1)},${height - (point.value / 100) * height}`);
    if (coordinates.length === 1) {
      const circle = document.createElementNS(svg.namespaceURI, "circle");
      const [cx, cy] = coordinates[0].split(",");
      circle.setAttribute("cx", cx); circle.setAttribute("cy", cy); circle.setAttribute("r", "2.5"); circle.setAttribute("fill", "#76baff"); svg.append(circle);
    } else {
      const line = document.createElementNS(svg.namespaceURI, "polyline");
      line.setAttribute("points", coordinates.join(" ")); line.setAttribute("fill", "none"); line.setAttribute("stroke", "#76baff"); line.setAttribute("stroke-width", "2"); line.setAttribute("vector-effect", "non-scaling-stroke"); svg.append(line);
    }
  };
  for (const sample of samples.map((item, index) => ({ item, index, value: item.gpu_utilization_percent, timestamp: Date.parse(item.timestamp || "") }))) {
    const valid = Number.isFinite(sample.value) && sample.value >= 0 && sample.value <= 100;
    const gap = previous && Number.isFinite(sample.timestamp) && Number.isFinite(previous.timestamp) && sample.timestamp - previous.timestamp > 5000;
    if (!valid || gap) { drawSegment(); segment = []; }
    if (valid) segment.push({ index: sample.index, value: sample.value });
    previous = sample;
  }
  drawSegment();
  const timeSamples = samples.filter((sample) => Number.isFinite(Date.parse(sample.timestamp || "")));
  const axis = document.createElementNS(svg.namespaceURI, "text");
  const startLabel = timeSamples[0] ? new Date(timeSamples[0].timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "Time unavailable";
  const endLabel = timeSamples.at(-1) ? new Date(timeSamples.at(-1).timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "";
  axis.setAttribute("x", "0"); axis.setAttribute("y", "101"); axis.setAttribute("fill", "#6d7a8d"); axis.setAttribute("font-size", "8");
  axis.textContent = endLabel ? `${startLabel} — ${endLabel}` : startLabel;
  svg.append(axis);
  chart.replaceChildren(svg);
  chart.setAttribute("aria-label", `GPU activity samples, ${values.length} observations`);
  text("gpu-device", samples[0].device_name || "Device samples");
  text("gpu-average", `${(values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(1)}% · n=${values.length}`);
  const vram = [...samples].reverse().find((sample) => Number.isFinite(sample.vram_used_bytes) && Number.isFinite(sample.vram_total_bytes));
  text("gpu-vram", Number.isFinite(vram.vram_used_bytes) && Number.isFinite(vram.vram_total_bytes) ? `${formatBytes(vram.vram_used_bytes)} / ${formatBytes(vram.vram_total_bytes)}` : "—");
}

function renderCapabilities(state) {
  const capabilities = state.status?.capabilities || {};
  for (const item of document.querySelectorAll("[data-capability]")) {
    const name = item.dataset.capability;
    const value = capabilities[name];
    const stateValue = typeof value === "string" ? value : value?.state || "unavailable";
    item.textContent = capabilityLabel(stateValue);
    item.dataset.state = stateValue;
  }
  const requestState = capabilities.request_lifecycle?.state || state.captureState;
  text("coverage-summary", requestState === "unavailable" ? "Inventory only" : capabilityLabel(requestState));
}

function renderModelCards(state) {
  const root = byId("model-cards");
  if (!root) return;
  const focusedModel = document.activeElement?.dataset?.modelId;
  if (!state.models.length) {
    root.replaceChildren(make("section", "panel page-empty", "No model inventory is available."));
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const model of state.models) {
    const card = make("article", "model-card");
    const top = make("div", "model-card-header");
    const heading = make("div", "");
    heading.append(make("h2", "", model.name || model.provider_model_id || "Unknown model"), make("p", "", model.provider_model_id || "Provider model ID unavailable"));
    top.append(heading, make("span", `state-badge ${model.state === "loaded" ? "" : ""}`, model.state === "loaded" ? "Loaded" : model.state === "not-loaded" ? "Not loaded" : "Unknown"));
    card.append(top);
    const server = state.servers.find((item) => item.server_instance_id === model.server_instance_id);
    card.append(make("p", "", `${providerLabel(server?.provider_type)} · ${server?.endpoint || "Server unavailable"}`));
    const list = document.createElement("dl");
    const contexts = Array.isArray(model.loaded_context_lengths) && model.loaded_context_lengths.length ? model.loaded_context_lengths.join(" / ") : Number.isSafeInteger(model.context_length) ? model.context_length.toLocaleString() : "Unavailable";
    const modelRequests = state.requests.filter((request) => request.provider_model_id === model.provider_model_id || request.model_instance_id === model.model_instance_id).length;
    const requestCount = state.captureState === "unavailable" ? "Unavailable" : String(modelRequests);
    const rows = [["Quantization", model.quantization || "Unavailable"], ["Loaded context", contexts], ["Maximum context", Number.isSafeInteger(model.max_context_length) ? model.max_context_length.toLocaleString() : "Unavailable"], ["Loaded instances", Number.isSafeInteger(model.loaded_instance_count) ? model.loaded_instance_count : "Unavailable"], ["Observed requests", requestCount]];
    for (const [label, value] of rows) list.append(make("dt", "", label), make("dd", "", String(value)));
    card.append(list);
    const button = make("button", "button button-primary", "View requests");
    button.type = "button"; button.dataset.modelId = model.model_instance_id || model.provider_model_id; button.dataset.action = "filter-model";
    card.append(button);
    fragment.append(card);
  }
  root.replaceChildren(fragment);
  if (focusedModel) root.querySelector(`[data-model-id="${CSS.escape(focusedModel)}"]`)?.focus({ preventScroll: true });
}


function renderHistory(state) {
  if (state.page !== "history") return;
  const emptyEl = byId("history-empty");
  const contentEl = byId("history-content");
  if (!emptyEl || !contentEl) return;

  const serverFilter = byId("history-server-filter");
  if (serverFilter && (serverFilter.children.length <= 1 || state.servers.length > 0)) {
    const currentServer = state.historyServerFilter || "all";
    const serverOptions = [makeOption("all", "All servers")];
    for (const s of state.servers) {
      const sId = s.server_instance_id || s.id;
      if (!sId) continue;
      serverOptions.push(makeOption(sId, s.name || s.server_instance_id || sId));
    }
    serverFilter.replaceChildren(...serverOptions);
    serverFilter.value = currentServer;
  }

  const timeFilter = byId("history-time-filter");
  if (timeFilter) {
    timeFilter.value = state.historyTimeFilter || "all";
  }

  const modelFilter = byId("history-model-filter");
  if (modelFilter && modelFilter.children.length <= 1) {
    const currentVal = state.historyModelFilter || "all";
    const models = Array.from(new Set(state.historyRequests.map((r) => r.model_name || r.provider_model_id).filter(Boolean))).sort();
    const options = [makeOption("all", "All recorded models")];
    for (const m of models) {
      options.push(makeOption(m, m));
    }
    modelFilter.replaceChildren(...options);
    modelFilter.value = currentVal;
  }

  const hasRequests = Array.isArray(state.historyRequests) && state.historyRequests.length > 0;
  if (!hasRequests) {
    emptyEl.hidden = false;
    contentEl.hidden = true;
    if (state.historyAvailability === "disabled") {
      text("history-empty-title", "Inference history recording is not enabled");
      text("history-empty-desc", "Inference recording is disabled by default to preserve privacy and minimize disk I/O. Use --record-inferences {metadata,content} to persist inference telemetry.");
    } else {
      text("history-empty-title", "No recorded request history");
      text("history-empty-desc", "No inference requests matching the selected filters have been recorded yet.");
    }
    return;
  }

  emptyEl.hidden = true;
  contentEl.hidden = false;
  text("history-count-badge", `${state.historyTotalCount || state.historyRequests.length} recorded`);

  const listEl = byId("history-requests-list");
  if (listEl) {
    const items = state.historyRequests.map((req) => {
      const selected = req.request_id === state.selectedHistoryRequestId;
      const item = make("div", "request-card");
      item.setAttribute("role", "option");
      item.setAttribute("aria-selected", selected ? "true" : "false");
      item.dataset.requestId = req.request_id;
      item.tabIndex = 0;

      const header = make("div", "request-card-header");
      const title = make("div", "request-card-title", req.model_name || req.provider_model_id || "Unknown model");
      const badge = stateBadge(req.state);
      header.append(title, badge);

      const meta = make("div", "request-card-meta");
      const idSpan = make("span", "request-id", shortId(req.request_id, 16));
      const timeSpan = make("span", "request-time", formatShortTime(req.started_at));
      const durSpan = make("span", "request-duration", formatDuration(req.elapsed_seconds));
      meta.append(idSpan, timeSpan, durSpan);

      const tokens = make("div", "request-card-tokens");
      const inp = make("span", "token-pill", `In: ${req.input_tokens ?? "—"}`);
      const out = make("span", "token-pill", `Out: ${req.output_tokens ?? "—"}`);
      tokens.append(inp, out);
      if (req.recording_mode) {
        const isContent = req.recording_mode === "content";
        const modeBadge = make("span", `mode-badge ${isContent ? "mode-badge-content" : "mode-badge-metadata"}`, isContent ? "Content" : "Metadata");
        tokens.append(modeBadge);
      }

      item.append(header, meta, tokens);
      return item;
    });
    listEl.replaceChildren(...items);
  }

  const inspectorBody = byId("history-inspector-body");
  const inspectorBadge = byId("history-inspector-badge");
  if (inspectorBody) {
    const detail = state.selectedHistoryDetail;
    if (!detail) {
      if (inspectorBadge) inspectorBadge.textContent = "Select a request";
      inspectorBody.replaceChildren(make("p", "content-unavailable", "Select a request from the list to inspect historical telemetry and content."));
      return;
    }
    if (inspectorBadge) inspectorBadge.textContent = shortId(detail.request_id, 14);

    const container = make("div", "history-detail-container");

    const metaGrid = make("div", "detail-meta-grid");
    const addField = (lbl, val) => {
      const field = make("div", "detail-meta-field");
      field.append(make("span", "detail-meta-label", lbl));
      field.append(make("strong", "detail-meta-value", val ?? "—"));
      metaGrid.append(field);
    };
    addField("Model", detail.model_name || detail.provider_model_id);
    addField("Server", detail.server_instance_id || "—");
    addField("State", detail.state);
    addField("Recording", detail.recording_mode ? (detail.recording_mode === "content" ? "Content (Full)" : "Metadata (Redacted)") : "—");
    addField("Duration", formatDuration(detail.elapsed_seconds));
    addField("Started", formatTimestamp(detail.started_at));
    addField("Completed", formatTimestamp(detail.ended_at));
    addField("Tokens in/out", `${detail.input_tokens ?? "—"} / ${detail.output_tokens ?? "—"}`);
    addField("Speed", formatMetric(detail.generation_tokens_per_second, "tok/s"));
    addField("TTFT", formatMetric(detail.time_to_first_text_seconds, "s"));
    container.append(metaGrid);

    const hwList = detail.hardware_samples || [];
    const hwCard = make("div", "history-hw-card");
    hwCard.append(make("h3", "history-subheading", "Hardware Telemetry"));
    if (hwList.length > 0) {
      const avgGpu = detail.gpu_average_percent != null ? `${detail.gpu_average_percent.toFixed(1)}%` : "—";
      const peakVram = detail.gpu_peak_vram_bytes != null ? formatBytes(detail.gpu_peak_vram_bytes) : "—";
      const hwSummary = make("p", "hw-summary-text", `Average GPU: ${avgGpu} · Peak VRAM: ${peakVram} · Samples: ${hwList.length}`);
      hwCard.append(hwSummary);
    } else {
      hwCard.append(make("p", "content-unavailable", "No hardware samples recorded during this request."));
    }
    container.append(hwCard);

    const contentCard = make("div", "history-content-card");
    contentCard.append(make("h3", "history-subheading", "Request & Output Content"));
    const contents = detail.content || [];
    if (contents.length > 0) {
      const msgList = make("div", "history-messages");
      for (const msg of contents) {
        const msgEl = make("div", `history-message message-${msg.kind || msg.role || "other"}`);
        const roleBadge = make("span", "message-role", msg.role || msg.kind || "message");
        const body = make("div", "message-text", msg.text || "");
        msgEl.append(roleBadge, body);
        msgList.append(msgEl);
      }
      contentCard.append(msgList);
    } else if (detail.recording_mode === "metadata") {
      contentCard.append(make("p", "content-unavailable", "Request content was not persisted in metadata recording mode to guarantee operator privacy."));
    } else {
      contentCard.append(make("p", "content-unavailable", "No text content recorded for this request."));
    }
    container.append(contentCard);

    inspectorBody.replaceChildren(container);
  }
}

function renderAlerts(state) {
  const container = byId("alerts-container");
  if (!container) return;

  const cards = [];
  let warningCount = 0;

  // 1. Server Connectivity
  const connectedServers = state.servers.filter((s) => s.connection_state === "connected");
  const totalServers = state.servers.length;
  let serverCard;
  if (connectedServers.length > 0) {
    const names = connectedServers.map((s) => s.name || s.server_instance_id || "Server").join(", ");
    serverCard = createAlertCard(
      "Server Connectivity",
      "Healthy",
      "alert-healthy",
      "badge-healthy",
      `Connected to ${connectedServers.length} local inference server(s): ${names}. Inventory discovery and endpoint communication active.`,
      `Endpoints verified · ${totalServers} configured`
    );
  } else if (totalServers > 0) {
    warningCount++;
    serverCard = createAlertCard(
      "Server Connectivity",
      "Critical",
      "alert-critical",
      "badge-critical",
      `${totalServers} local server(s) configured, but none are currently reachable. Verify the LM Studio process is running.`,
      "Connection state: offline / unreachable"
    );
  } else {
    warningCount++;
    serverCard = createAlertCard(
      "Server Connectivity",
      "Warning",
      "alert-warning",
      "badge-warning",
      "No inference servers discovered or registered. Monitoring cannot inspect models or capture requests without an active server.",
      "Discovery status: zero servers detected"
    );
  }
  cards.push(serverCard);

  // 2. Request Stream & Reliability
  const failedRequests = state.requests.filter((r) => r.state === "failed");
  const hasGaps = state.requestGap || state.requests.some((r) => r.stream_gap);
  let streamCard;
  if (failedRequests.length > 0) {
    warningCount++;
    streamCard = createAlertCard(
      "Inference Reliability",
      "Warning",
      "alert-warning",
      "badge-warning",
      `${failedRequests.length} inference request(s) failed out of ${state.requests.length} observed in active window. Inspect request stream for error causes.`,
      `Failed: ${failedRequests.length} · Total: ${state.requests.length}`
    );
  } else if (hasGaps) {
    warningCount++;
    streamCard = createAlertCard(
      "Observation Integrity",
      "Warning",
      "alert-warning",
      "badge-warning",
      "Stream sequence gap detected. Some live tokens or telemetry events were interrupted or lost in transit.",
      "Integrity status: sequence gap observed"
    );
  } else if (state.requests.length > 0) {
    streamCard = createAlertCard(
      "Inference Reliability",
      "Healthy",
      "alert-healthy",
      "badge-healthy",
      `All ${state.requests.length} observed request(s) completed without observation gaps or client errors.`,
      "Stream integrity: continuous"
    );
  } else {
    streamCard = createAlertCard(
      "Inference Stream",
      "Info",
      "alert-info",
      "badge-info",
      "Gateway is listening and ready. Waiting for inference requests from clients (e.g. OpenCode, Aider, or curl).",
      "Observation status: awaiting requests"
    );
  }
  cards.push(streamCard);

  // 3. Hardware Telemetry & GPU Sampling
  const hwSamples = Array.isArray(state.status?.hardware_samples) ? state.status.hardware_samples : [];
  const hasGpu = hwSamples.some((s) => Number.isFinite(s.gpu_utilization_percent) && s.gpu_utilization_percent >= 0);
  let gpuCard;
  if (hasGpu) {
    const latestGpu = hwSamples.at(-1);
    const util = latestGpu?.gpu_utilization_percent != null ? `${latestGpu.gpu_utilization_percent.toFixed(0)}%` : "—";
    const vram = latestGpu?.vram_used_bytes != null ? formatBytes(latestGpu.vram_used_bytes) : "—";
    gpuCard = createAlertCard(
      "Hardware Telemetry",
      "Healthy",
      "alert-healthy",
      "badge-healthy",
      `Real NVIDIA GPU telemetry active via NVML. Real-time GPU load: ${util}, VRAM in use: ${vram}. Request-hardware correlation enabled.`,
      `Samples collected: ${hwSamples.length}`
    );
  } else {
    gpuCard = createAlertCard(
      "Hardware Telemetry",
      "Info",
      "alert-info",
      "badge-info",
      "NVIDIA GPU hardware metrics are currently unavailable. Ensure nvidia-smi / NVML is accessible if hardware sampling is expected.",
      "Hardware provider: unavailable or uninitialized"
    );
  }
  cards.push(gpuCard);

  // 4. Persistence & Storage Health
  const recInfo = state.status?.recording;
  const recMode = recInfo?.mode || (recInfo?.enabled ? "metadata" : "off");
  let storageCard;
  if (recMode === "content") {
    storageCard = createAlertCard(
      "Inference Recording",
      "Active (Content)",
      "alert-healthy",
      "badge-healthy",
      "Full content recording is active. Request prompts, reasoning text, assistant outputs, and hardware metrics are persisted to SQLite.",
      `Database: ${recInfo?.database_path || "configured SQLite"} · Retention: persistent`
    );
  } else if (recMode === "metadata") {
    storageCard = createAlertCard(
      "Inference Recording",
      "Active (Metadata)",
      "alert-info",
      "badge-info",
      "Metadata recording is active. Request timing, token counts, and GPU correlation are persisted. Content payloads are stripped for privacy.",
      `Database: ${recInfo?.database_path || "configured SQLite"} · Privacy: content redacted`
    );
  } else {
    storageCard = createAlertCard(
      "Inference Recording",
      "Disabled",
      "alert-info",
      "badge-info",
      "Persistent recording is disabled by default. Inference requests are tracked in-memory only and will be cleared upon process restart.",
      "Mode: memory-only"
    );
  }
  cards.push(storageCard);

  // 5. Capability Matrix Card
  const matrixCard = make("div", "alert-card alert-info");
  const matrixHeader = make("div", "alert-card-header");
  matrixHeader.append(make("h2", "alert-card-title", "Collection & Telemetry Capability Matrix"));
  matrixHeader.append(make("span", "alert-card-badge badge-info", "Runtime"));
  matrixCard.append(matrixHeader);

  const table = make("table", "coverage-matrix-table");
  const thead = make("thead");
  const headRow = make("tr");
  headRow.append(make("th", "", "Capability"));
  headRow.append(make("th", "", "State"));
  headRow.append(make("th", "", "Observation Channel"));
  thead.append(headRow);
  table.append(thead);

  const tbody = make("tbody");
  const caps = [
    { name: "Model inventory", state: state.servers.length ? "Available" : "Unavailable", channel: "LM Studio /api/v1/models" },
    { name: "Request lifecycle", state: state.requests.length ? "Streaming" : "Available", channel: "OpenAI Gateway /v1/chat/completions" },
    { name: "Structured input", state: recMode === "content" ? "Available" : "Rendered only", channel: "Gateway request body parser" },
    { name: "Reasoning stream", state: "Streaming", channel: "Live SSE chunk analyzer" },
    { name: "Output stream", state: "Streaming", channel: "Live SSE chunk analyzer" },
    { name: "Token usage", state: "Available", channel: "Provider reported & calculated" },
    { name: "Request timing", state: "Available", channel: "High-resolution monotonic timer" },
    { name: "Aggregate metrics", state: "Available", channel: "In-memory rolling accumulator" },
    { name: "GPU / VRAM samples", state: hasGpu ? "Available" : "Unavailable", channel: "NVIDIA Management Library (NVML)" },
    { name: "Historical persistence", state: recMode !== "off" ? "Active" : "Disabled", channel: "SQLite inference store" },
  ];

  for (const cap of caps) {
    const row = make("tr");
    row.append(make("td", "", cap.name));
    const badgeTd = make("td");
    const stBadge = make("span", `combobox-option-badge ${cap.state === "Available" || cap.state === "Streaming" || cap.state === "Active" ? "badge-loaded" : "badge-not-loaded"}`, cap.state);
    badgeTd.append(stBadge);
    row.append(badgeTd);
    row.append(make("td", "", cap.channel));
    tbody.append(row);
  }
  table.append(tbody);
  matrixCard.append(table);
  cards.push(matrixCard);

  container.replaceChildren(...cards);

  // Update navigation alert counter
  const navAlertCount = byId("alert-count");
  if (navAlertCount) {
    if (warningCount > 0) {
      navAlertCount.textContent = String(warningCount);
      navAlertCount.hidden = false;
    } else {
      navAlertCount.hidden = true;
    }
  }
}

function createAlertCard(title, badgeText, cardClass, badgeClass, bodyText, metaText) {
  const card = make("div", `alert-card ${cardClass}`);
  const header = make("div", "alert-card-header");
  header.append(make("h2", "alert-card-title", title));
  header.append(make("span", `alert-card-badge ${badgeClass}`, badgeText));
  card.append(header);
  card.append(make("p", "alert-card-body", bodyText));
  if (metaText) card.append(make("span", "alert-card-meta", metaText));
  return card;
}

function renderPage(state) {
  const activePage = state.page === "requests" ? "overview" : state.page;
  for (const page of document.querySelectorAll("[data-view]")) page.hidden = page.dataset.view !== activePage;
  for (const link of document.querySelectorAll("[data-page]")) {
    const active = link.dataset.page === state.page;
    link.classList.toggle("is-active", active);
    if (active) link.setAttribute("aria-current", "page"); else link.removeAttribute("aria-current");
  }
}

function stateBadge(state, className = "state-badge") {
  const badge = make("span", className, stateLabel(state));
  badge.dataset.state = isActive(state) ? "active" : String(state || "unknown").toLowerCase();
  return badge;
}

function renderStateBadge(id, state) {
  const badge = byId(id);
  badge.textContent = stateLabel(state);
  badge.dataset.state = isActive(state) ? "active" : String(state || "unknown").toLowerCase();
}

function setTokenMetric(id, request, field) {
  text(id, tokenMetric(request, field).value);
}

function previewText(request) {
  const input = (request.content || []).find((item) => ["user", "system", "developer"].includes(item.kind) && item.text);
  if (input) return input.text.replace(/\s+/g, " ").trim();
  return request.coverage?.structured_input === "rendered_only" ? "Input rendered by observation source" : "Input unavailable · metadata-only observation";
}

function sourceLabel(source) {
  return String(source || "unavailable").replaceAll("_", " ");
}

function providerLabel(provider) {
  return provider ? String(provider).toUpperCase() : "Inference server";
}

function connectionLabel(state) {
  return ({ connected: "connected", unavailable: "disconnected", discovering: "discovering" })[state] || "unknown";
}

function shortId(id, length = 18) {
  const value = String(id || "request unavailable");
  return value.length > length ? `${value.slice(0, length - 1)}…` : value;
}

function formatShortTime(value) {
  const date = new Date(value || "");
  return Number.isNaN(date.getTime()) ? "Time unknown" : date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function formatMetric(value, unit) {
  if (!Number.isFinite(value) || value < 0) return "Unavailable";
  const textValue = unit === "bytes" ? formatBytes(value) : Number.isInteger(value) ? value.toLocaleString() : value.toFixed(2);
  return unit === "s" ? `${textValue}s` : unit === "tok/s" ? `${textValue} tok/s` : unit === "bytes" ? textValue : `${textValue} ${unit}`;
}

function formatBytes(value) {
  if (!Number.isFinite(value) || value < 0) return "—";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let amount = value, index = 0;
  while (amount >= 1024 && index < units.length - 1) { amount /= 1024; index += 1; }
  return `${amount.toFixed(index ? 1 : 0)} ${units[index]}`;
}

function formatRelative(value, origin) {
  const timestamp = Date.parse(value || "");
  const start = Date.parse(origin || "");
  if (!Number.isFinite(timestamp)) return "Time unavailable";
  const absolute = new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  return Number.isFinite(start) ? `+${((timestamp - start) / 1000).toFixed(2)}s · ${absolute}` : absolute;
}

function eventLabel(type) {
  return String(type || "event").replaceAll(".", " ").replaceAll("_", " ");
}

function make(tag, className = "", value = "") {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (value !== undefined && value !== null) element.textContent = String(value);
  return element;
}

function makeOption(value, label) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = label;
  return option;
}

function replaceText(node, value) {
  if (node) node.textContent = value;
}

function text(id, value) {
  const node = byId(id);
  if (node) node.textContent = value === undefined || value === null ? "—" : String(value);
}

function byId(id) {
  return document.getElementById(id);
}
