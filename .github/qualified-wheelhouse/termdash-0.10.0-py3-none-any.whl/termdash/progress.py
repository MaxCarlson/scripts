#!/usr/bin/env python3
from __future__ import annotations

import shutil
from typing import Callable, Optional, Tuple, Union

from .components import Stat


CharSet = Tuple[str, str]  # (fill, empty)


def _term_cols(default: int = 80) -> int:
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default


class ProgressBar:
    """
    Fixed or full-width textual progress bar that plugs into a Line as a Stat.

    - Can be bound to functions returning (current, total) so it always
      reflects the *actual* progress at render time.
    - Uses no_expand=True so it won't distort column alignment.
    - Full-width mode draws a bar that spans the entire terminal width
      (useful for "bar below the row" layouts).

    Parameters
    ----------
    name : str
        Unique stat name.
    total : float | int
        Total units of work.
    current : float | int
        Starting units completed.
    width : int
        Bar width when full_width=False (includes the [..] brackets).
    charset : {"block", "ascii"} or CharSet
        "block" -> ("█", "·"), "ascii" -> ("#", "-"), or a tuple (fill, empty).
    show_percent : bool
        Overlay a centered "xx%" in the bar.
    full_width : bool
        If True, bar spans the terminal width (computed on render).
    margin : int
        Horizontal margin to subtract from terminal width in full_width mode.
    """

    def __init__(
        self,
        name: str,
        total: Union[int, float],
        current: Union[int, float] = 0,
        *,
        width: int = 30,
        charset: Union[str, CharSet] = "block",
        show_percent: bool = True,
        full_width: bool = False,
        margin: int = 2,
        min_width_fraction: Optional[float] = None,
    ) -> None:
        self.name = name
        self._total = max(0.0, float(total))
        self._current = max(0.0, float(current))
        self.width = max(6, int(width))
        self.show_percent = bool(show_percent)
        self.full_width = bool(full_width)
        self.margin = max(0, int(margin))
        self.min_width_fraction = min_width_fraction

        if isinstance(charset, tuple):
            self.fill_char, self.empty_char = charset
        elif charset == "ascii":
            self.fill_char, self.empty_char = "#", "-"
        else:
            # Use a high-contrast empty so "0%" isn't invisible.
            self.fill_char, self.empty_char = "█", "·"

        # Stat that renders this bar; value is `self` so Stat->format->str(self)
        display_width = None if self.full_width else self.width
        self._stat = Stat(
            name,
            value=self,
            format_string="{}",
            no_expand=True,  # never push column widths
            display_width=display_width,  # provide width hint for no_expand columns
        )
        # Optional live bindings
        self._current_fn: Optional[Callable[[], float]] = None
        self._total_fn: Optional[Callable[[], float]] = None

    # --------------- public API ----------------

    def cell(self) -> Stat:
        """Return the Stat to insert in a Line."""
        return self._stat

    def bind(
        self,
        *,
        current_fn: Optional[Callable[[], Union[int, float]]] = None,
        total_fn: Optional[Callable[[], Union[int, float]]] = None,
    ) -> None:
        self._current_fn = (lambda: float(current_fn())) if current_fn else None
        self._total_fn = (lambda: float(total_fn())) if total_fn else None

    def set_total(self, total: Union[int, float]) -> None:
        self._total = max(0.0, float(total))

    def set(self, current: Union[int, float]) -> None:
        self._current = max(0.0, float(current))

    def advance(self, delta: Union[int, float] = 1) -> None:
        self._current = max(0.0, self._current + float(delta))

    def percent(self) -> float:
        t = self._total_fn() if self._total_fn else self._total
        c = self._current_fn() if self._current_fn else self._current
        if t <= 0:
            return 0.0
        return max(0.0, min(100.0, 100.0 * (c / t)))

    # -------------- rendering core -------------

    def __str__(self) -> str:
        """Build the bar string every time the Stat is rendered."""
        t = self._total_fn() if self._total_fn else self._total
        c = self._current_fn() if self._current_fn else self._current
        t = max(0.0, float(t))
        c = max(0.0, float(c))

        pct = 0.0 if t <= 0 else max(0.0, min(1.0, c / t))

        # Width: fixed or full-terminal
        if self.full_width:
            w = max(6, _term_cols() - self.margin)
        else:
            w = self.width
            if self.min_width_fraction is not None:
                min_w = int(_term_cols() * self.min_width_fraction)
                w = max(w, min_w)

        inner = max(2, w - 2)  # reserve [ .. ]
        filled = int(round(inner * pct))
        empty = max(0, inner - filled)

        # Base bar
        bar_chars = [self.fill_char] * filled + [self.empty_char] * empty

        # Overlay percent text *inside* the bar if requested
        if self.show_percent:
            text = f"{int(round(100 * pct)):3d}%"
            start = max(0, (inner - len(text)) // 2)
            for i, ch in enumerate(text):
                if 0 <= start + i < len(bar_chars):
                    bar_chars[start + i] = ch

        return "[" + "".join(bar_chars) + "]"


def render_horizontal_bar(
    ratio: float,
    *,
    width: int = 20,
    fill_char: str = "█",
    empty_char: str = " ",
    color: str | None = None,
    brackets: bool = True,
    show_pct: bool = False,
) -> str:
    """
    Render a horizontal comparison bar for reports, tables, and comparative stats.

    Parameters
    ----------
    ratio : float
        Value between 0.0 and 1.0 (clamped).
    width : int
        Total width of the bar (including brackets if brackets=True).
    fill_char : str
        Character for the filled portion (default: '█').
    empty_char : str
        Character for the empty portion (default: ' ').
    color : str | None
        Optional ANSI color name for the filled portion ('green', 'cyan', 'yellow', etc.).
    brackets : bool
        Whether to wrap in '[' and ']' (default: True).
    show_pct : bool
        Whether to append ' XX.X%' after the bar.
    """
    from .utils import color_text

    r = max(0.0, min(1.0, float(ratio)))
    width = max(0, int(width))
    if len(fill_char) != 1 or len(empty_char) != 1:
        raise ValueError("Bar fill and empty characters must be single characters")
    brackets = brackets and width >= 2
    bracket_overhead = 2 if brackets else 0
    inner_width = max(0, width - bracket_overhead)
    filled_len = int(round(inner_width * r))
    empty_len = max(0, inner_width - filled_len)

    filled_str = fill_char * filled_len
    if color:
        filled_str = color_text(filled_str, color)
    empty_str = empty_char * empty_len

    bar = (f"[{filled_str}{empty_str}]") if brackets else f"{filled_str}{empty_str}"
    if show_pct:
        bar = f"{bar} {r * 100:5.1f}%"
    return bar
