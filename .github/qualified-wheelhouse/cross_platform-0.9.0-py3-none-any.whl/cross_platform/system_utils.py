import platform
import subprocess
import os
from .debug_utils import write_debug

class SystemUtils:
    """Base class for cross-platform system utilities."""

    def __init__(self):
        self.os_name = platform.system().lower()
        write_debug(f"Initialized SystemUtils for OS: {self.os_name}", channel="Debug")

    def is_termux(self) -> bool:
        is_termux = "ANDROID_ROOT" in os.environ and "com.termux" in os.environ.get("SHELL", "")
        write_debug(f"is_termux: {is_termux}", channel="Debug")
        return is_termux

    def is_tmux(self) -> bool:
        """Check if running inside a tmux session."""
        is_tmux_session = "TMUX" in os.environ
        write_debug(f"is_tmux: {is_tmux_session}", channel="Debug")
        return is_tmux_session

    def is_wsl2(self) -> bool:
        """
        Detect if running under WSL2.
        Returns True if the release string (from uname) contains 'microsoft'.
        """
        is_wsl = "microsoft" in platform.uname().release.lower()
        write_debug(f"is_wsl2: {is_wsl}", channel="Debug")
        return is_wsl

    def is_windows(self) -> bool:
        """Check if running on Windows (not WSL)."""
        is_win = self.os_name == "windows"
        write_debug(f"is_windows: {is_win}", channel="Debug")
        return is_win

    def is_linux(self) -> bool:
        """Check if running on Linux (includes WSL and Termux)."""
        is_lin = self.os_name == "linux"
        write_debug(f"is_linux: {is_lin}", channel="Debug")
        return is_lin

    def is_darwin(self) -> bool:
        """Check if running on macOS."""
        is_mac = self.os_name == "darwin"
        write_debug(f"is_darwin: {is_mac}", channel="Debug")
        return is_mac

    def is_macos(self) -> bool:
        """Alias for is_darwin()."""
        return self.is_darwin()

    def run_command(self, command: str, sudo: bool = False) -> str:
        """
        Execute a system command with optional sudo privileges.
        """
        try:
            if sudo and self.os_name in ["linux", "darwin"] and not self.is_termux():
                command = f"sudo {command}"
                write_debug(f"Prepended sudo: {command}", channel="Debug")
            write_debug(f"Running command: {command}", channel="Debug")
            result = subprocess.run(command, shell=True, text=True, capture_output=True)
            if result.returncode == 0:
                write_debug(f"Command succeeded: {command}", channel="Debug")
                return result.stdout.strip()
            else:
                write_debug(f"Command failed: {command}\nError: {result.stderr.strip()}", channel="Error")
                return ""
        except Exception as e:
            write_debug(f"Exception while running command '{command}': {e}", channel="Critical")
            return ""

    def source_file(self, filepath: str) -> bool:
        """
        Source a file in the shell. This is intended for Unix-like systems.
        Returns True if the sourcing command succeeds, False otherwise.
        """
        try:
            # Only source on Linux or macOS (and not under Termux)
            if self.os_name in ["linux", "darwin"] and not self.is_termux():
                command = f"source {filepath}"
                write_debug(f"Attempting to source file with command: {command}", channel="Debug")
                result = subprocess.run(["zsh", "-c", command], text=True, capture_output=True)
                if result.returncode == 0:
                    write_debug(f"Sourced file successfully: {filepath}", channel="Debug")
                    return True
                else:
                    write_debug(f"Failed to source file: {filepath}\nError: {result.stderr.strip()}", channel="Error")
                    return False
            else:
                write_debug(f"Automatic sourcing not supported on OS: {self.os_name} or under Termux.", channel="Debug")
                return False
        except Exception as e:
            write_debug(f"Exception while sourcing file {filepath}: {e}", channel="Critical")
            return False

